#ifndef LIST_H
#define LIST_H

class List
{
   string* strings;
   int cursize;
   int maxsize;
   void resize ( int newsize = -1 )
   {
      if ( newsize == -1 )
         newsize = maxsize;
      if ( newsize > maxsize )
      {
         strings = new string[newsize - cursize];
         maxsize = newsize;
      }
   };

public:
   List()
   {
      maxsize = 50;
      strings = new string[maxsize];
      cursize = 0;
   };

   List ( int initialsize )
   {
      strings = new string[initialsize];
      maxsize = initialsize;
      cursize = 0;
   };

   void add ( string newentry, int pos = -1, int rflag = 0 )
   {
      if ( pos == -1 )
         pos = cursize;
      if ( pos < maxsize && pos >= 0 )
      {
		   if ( !rflag )
			   for ( int i = pos; i < cursize; i++ )
				   strings[i + 1] = strings[i];
		   strings[pos] = newentry;
         cursize++;
         if ( cursize == maxsize )
            resize();
      }
   };

   void add ( char* newentry, int pos = -1, int rflag = 0 )
   {
      string s(newentry);
      add ( s, pos, rflag );
   };

   void remove ( string entry )
   {
      for ( int i = 0; i < cursize; i++ )
         if ( strings[i] == entry )
         {
            for ( int j = i; j < cursize - 1; j++ )
               strings[j] = strings[j + 1];
            cursize--;
            break;
         }
   };

   void remove ( int pos )
   {
      if ( pos >= 0 && pos < cursize )
      {
         for ( int i = pos; i < cursize - 1; i++ )
            strings[i] = strings[i + 1];
         cursize--;
      }
   };

   int size() const
   {
      return cursize;
   };

   string get ( int pos )
   {
      if ( pos >= 0 && pos < cursize )
         return strings[pos];
      return 0;
   };
};

#endif /* end LIST_H */
