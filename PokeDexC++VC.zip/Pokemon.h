#ifndef POKEMON_H
#define POKEMON_H

class Pokemon
{
   string name, type, location;
   List attack, breed, moves, tmhm, evolution;
   int number;
public:
   Pokemon()
   {
	   number = 0;
	   name = "";
	   type = "";
	   location = "";
   };

   Pokemon ( int num, string nm, string tp, string loc, List atk, List brd, List mvs, List th, List evo )
   {
      number = num;
      name = nm;
      type = tp;
      location = loc;
      attack = atk;
      breed = brd;
      moves = mvs;
      tmhm = th;
      evolution = evo;
   };

   Pokemon ( const Pokemon& pkmn )
   {
      number = pkmn.getNumber();
      name = pkmn.getName();
      type = pkmn.getType();
      location = pkmn.getLocation();
      attack = pkmn.getAttack();
      breed = pkmn.getBreed();
      moves = pkmn.getMoves();
      tmhm = pkmn.getTMHM();
      evolution = pkmn.getEvolution();
   };
   
   string getName() const
   {
      return name;
   };

   string getType() const
   {
      return type;
   };

   string getLocation() const
   {
      return location;
   };

   int getNumber() const
   {
      return number;
   };

   List getAttack() const
   {
      return attack;
   };

   List getBreed() const
   {
      return breed;
   };

   List getMoves() const
   {
      return moves;
   };

   List getTMHM() const
   {
      return tmhm;
   };

   List getEvolution() const
   {
      return evolution;
   };
};

#endif /* end POKEMON_H */
