#ifndef SKILL_H
#define SKILL_H

class Skill
{
   string name, type, descr;
   int pwr, pp;
public:
   Skill()
   {
      name = "";type = "";descr = "";pwr = 0; pp = 0;
   };

   Skill ( string n, string t, string d, int pw, int p )
   {
      name = n;
      type = t;
      descr = d;
      pwr = pw;
      pp = p;
   };

   Skill ( const Skill &newskill )
   {
      name = newskill.getName();
      type = newskill.getType();
      descr = newskill.getDescr();
      pwr = newskill.getPower();
      pp = newskill.getPP();
   };

   string getName() const
   {
      return name;
   };

   string getType() const
   {
      return type;
   };

   string getDescr() const
   {
      return descr;
   };

   int getPower() const
   {
      return pwr;
   };

   int getPP() const
   {
      return pp;
   };
};

#endif /* END SKILL_H */
